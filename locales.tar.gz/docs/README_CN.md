<div align="center">

  <!-- Language Switcher -->
  <a href="README_CN.md">简体中文</a> | <a href="../README.md">English</a>

  <br>
  <br>

  <h1>千惠 MaiBot <sub><small>MaiSaka</small></sub></h1>

  <!-- Badges Row -->
  <p>
    <img src="https://img.shields.io/badge/Python-3.10+-blue" alt="Python Version">
    <img src="https://img.shields.io/github/license/Mai-with-u/MaiBot?label=%E5%8D%8F%E8%AE%AE" alt="License">
    <img src="https://img.shields.io/badge/状态-开发中-yellow" alt="Status">
    <img src="https://img.shields.io/github/contributors/Mai-with-u/MaiBot.svg?style=flat&label=%E8%B4%A1%E7%8C%AE%E8%80%85" alt="Contributors">
    <img src="https://img.shields.io/github/forks/Mai-with-u/MaiBot.svg?style=flat&label=%E5%88%86%E6%94%AF%E6%95%B0" alt="Forks">
    <img src="https://img.shields.io/github/stars/Mai-with-u/MaiBot?style=flat&label=%E6%98%9F%E6%A0%87%E6%95%B0" alt="Stars">
    <a href="https://deepwiki.com/DrSmoothl/MaiBot"><img src="https://deepwiki.com/badge.svg" alt="Ask DeepWiki"></a>
  </p>
</div>

<br>

<!-- Mascot on the Right (Float) -->
<img src="../depends-data/maimai-v2.png" align="right" width="40%" alt="MaiBot Character" style="margin-left: 20px; margin-bottom: 20px;">

## 介绍

千惠MaiSaka 是一个基于大语言模型的可交互智能体

MaiSaka 不仅仅是一个机器人，不仅仅是一个可以帮你完成任务的“有帮助的助手”，她还是一个致力于了解你，并以真实人类的风格进行交互的数字生命，她不追求完美，她不追求高效，但追求亲切和真实。


- 💭 **没有人喜欢GPT的语言风格**：千惠使用了更加自然，贴合人类对话习惯的交互方式，不是长篇大论或者markdown格式的分点，而是或长或短的闲谈。

- 🎭 **不再是傻乎乎的一问一答**：懂得在合适的时间说话，把握聊天中的气氛，在合适的时候开口，在合适的时候闭嘴。

- 🧠 **千惠·成为人类**：在多人对话中，千惠会模仿其他人的的说话风格，还会自主理解新词或者小圈子里的黑话，不断进化。

- ❤️ **永远都在更加了解你**：基于心理学中人格理论，千惠会不断积累对于你的了解，不论是你的信息，喜恶或是行为风格，她都记在心里。

- 🔌 **插件系统**：提供强大的 API 和事件系统，无限扩展可能。



### 快速导航
<p>
  <a href="https://www.bilibili.com/video/BV1amAneGE3P">🌟 演示视频</a> &nbsp;|&nbsp; 
  <a href="#-更新和安装">📦 快速入门</a> &nbsp;|&nbsp; 
  <a href="#-部署教程">📃 核心文档</a> &nbsp;|&nbsp; 
  <a href="#-讨论与社区">💬 加入社区</a>
</p>

<!-- Clear float to ensure subsequent content starts below the image area if text is short -->
<br clear="both">

<div align="center">
  <br>
  <a href="https://www.bilibili.com/video/BV1amAneGE3P" target="_blank">
    <picture>
      <source media="(max-width: 600px)" srcset="../depends-data/video.png" width="100%">
      <img src="../depends-data/video.png" width="60%" alt="千惠演示视频" style="border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
    </picture>
    <br>
    <small>前往观看千惠演示视频</small>
  </a>
</div>

---

## 🔥 更新和安装

> **最新版本: v1.0.0** ([📄 更新日志](../changelogs/changelog.md))

- **下载**: 前往 [Release](https://github.com/MaiM-with-u/MaiBot/releases/) 页面下载最新版本
- **启动器**: [Mailauncher](https://github.com/MaiM-with-u/mailauncher/releases/) (仅支持 MacOS, 早期开发中)

| 分支 | 说明 |
| :--- | :--- |
| `main` | ✅ **稳定发布版本 (推荐)** |
| `dev` | 🚧 开发测试版本，包含新功能，可能不稳定 |

### 📚 部署教程
👉 **[🚀 最新版本部署教程](https://docs.mai-mai.org/manual/deployment/mmc_deploy_windows.html)**  

---

## 💬 讨论与社区

我们欢迎所有对 MaiBot 感兴趣的朋友加入！

| 类别 | 群组 | 说明 |
| :--- | :--- | :--- |
| **技术交流** | [千惠脑电图](https://qm.qq.com/q/RzmCiRtHEW) | 技术交流/答疑 |
| **技术交流** | [千惠大脑磁共振](https://qm.qq.com/q/VQ3XZrWgMs) | 技术交流/答疑 |
| **技术交流** | [千惠要当VTB](https://qm.qq.com/q/wGePTl1UyY) | 技术交流/答疑 |
| **闲聊吹水** | [千惠之闲聊群](https://qm.qq.com/q/JxvHZnxyec) | 仅限闲聊，不答疑 |
| **插件开发** | [插件开发群](https://qm.qq.com/q/1036092828) | 进阶开发与测试 |

---

## 📚 文档

> [!NOTE]
> 部分内容可能更新不够及时，请注意版本对应。

- **[📚 核心 Wiki 文档](https://docs.mai-mai.org)**: 最全面的文档中心，了解千惠的一切。

### 🧩 衍生项目

- **[Amaidesu](https://github.com/MaiM-with-u/Amaidesu)**: 让千惠在B站开播
- **[MoFox_Bot](https://github.com/MoFox-Studio/MoFox-Core)**: 基于 MaiCore 0.10.0 的增强型 Fork，更稳定更有趣。
- **[MaiCraft](https://github.com/MaiM-with-u/Maicraft)**: 让千惠陪你玩 Minecraft (暂时停止维护中)。

---

## 💡 设计理念 

> **千石可乐说：**
> - 这个项目最初只是为了给牛牛 bot 添加一点额外的功能，但是功能越写越多，最后决定重写。其目的是为了创造一个活跃在 QQ 群聊的"生命体"。目的并不是为了写一个功能齐全的机器人，而是一个尽可能让人感知到真实的类人存在。
> - 程序的功能设计理念基于一个核心的原则："最像而不是好"。
> - 如果人类真的需要一个 AI 来陪伴自己，并不是所有人都需要一个完美的，能解决所有问题的"helpful assistant"，而是一个会犯错的，拥有自己感知和想法的"生命形式"。

> **xxxxx说：**
> *Code is open, but the soul is yours.*

---

## 🙋 贡献和致谢

欢迎参与贡献！请先阅读 [贡献指南](CONTRIBUTE.md)。

### 🌟 贡献者

<a href="https://github.com/MaiM-with-u/MaiBot/graphs/contributors">
  <img alt="contributors" src="https://contrib.rocks/image?repo=MaiM-with-u/MaiBot" />
</a>

### ❤️ 特别致谢

- **[萨卡班甲鱼](https://en.wikipedia.org/wiki/Sacabambaspis)**: 千石可乐很喜欢的生物。
- **[略nd](https://space.bilibili.com/1344099355)**: 🎨 为千惠绘制早期的精美人设。
- **[NapCat](https://github.com/NapNeko/NapCatQQ)**: 🚀 现代化的基于 NTQQ 的 Bot 协议实现。

---

## 📊 仓库状态

![Alt](https://repobeats.axiom.co/api/embed/9faca9fccfc467931b87dd357b60c6362b5cfae0.svg "千惠仓库状态")

### Star 趋势
[![Star 趋势](https://starchart.cc/MaiM-with-u/MaiBot.svg?variant=adaptive)](https://starchart.cc/MaiM-with-u/MaiBot)

---

## 📌 注意事项 & License

> [!IMPORTANT]
> 使用前请阅读 [用户协议 (EULA)](../EULA.md) 和 [隐私协议](../PRIVACY.md)。AI 生成内容请仔细甄别。

**License**: GPL-3.0
